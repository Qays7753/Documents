# Micro Live — Observed Session Notes (Sub-agent shared evidence)

- URL: https://micro-prototype.pages.dev — opened 2026-09-13, mobile viewport 390×844, Arabic RTL.
- Onboarding completed with a test project ("مشروع التجربة", wallet "الدرج", opening balance 1,500 JOD, one test sale 250 JOD cash). No credentials were requested or invented; setup is open onboarding.
- All observations below are what was actually seen in the running app. Screenshots in this folder.

## 1. Setup / onboarding
- PWA install banner on every screen until dismissed: "ثبّت Micro على جهازك — يفتح أسرع ويظل متاحًا بعد الزيارة الأولى" with buttons "تثبيت Micro" / "ليس الآن". Also permanent "الإعدادات" + "تفعيل المظهر الداكن" buttons floating top-left.
- Step 1: "ما اسم مشروعك؟" (h1) + single field + "التالي".
- Step 2: "وين تحط فلوسك؟" — default cash wallet name, prefilled "الدرج", with explicit skip "تخطَّ المحفظة الآن — أسجلها لاحقًا من «مالي»" and back.
- Step 3: "شو وضع الدرج هلق؟" — combobox "الموقف الافتتاحي": أعرف الرقم / ما بعرف الآن — يُحدَّد لاحقًا / بدأت من الصفر. Choosing "أعرف الرقم" reveals a numeric field (0.00). Save: "احفظ وافتح صفحة الأساس".
- Dialect: onboarding questions are Jordanian colloquial ("وين تحط فلوسك؟", "شو وضع الدرج هلق؟").
- Foundation page ("صفحة الأساس"): h1 "شو عندك هلق؟", subline "سجل ما تعرفه الآن فقط. ما تخطّاه يظهر لاحقًا كفجوة معلومة، لا رقم مخترع", region "سطر الحقيقة", three setup actions (محفظة ورصيد بداية / سجل استثمارًا نقديًا / رصيد سابق لحق المالك) + "فتح الاستيراد", exit actions "تخطَّ وأكمل لاحقًا" / "ادخل إلى مشروعي".

## 2. Home ("مشروعي الآن")
- Header: wordmark "مايكرو" + context label; avatar tile "M" in terracotta; settings + dark-mode toggle.
- H1 = project name; date "13/09/2026" in English numerals; "ملف المالك" link.
- Persistent status note: "بياناتك على هذا الجهاز فقط — انسخ نسخة احتياطية من الإعدادات لتصبح جاهزة للطوارئ." + link "افتح الإعدادات".
- "اليوم" card: strong "يومك مفتوح" + guidance "سجّل أول بيع أو طلب من زر «سجّل» في الأسفل — ما لا تسجله لا يُخترع له رقم." — STALE: after recording a sale, this card still says "سجّل أول بيع" (guidance does not update to the recorded state).
- "ما هو مسجل حتى الآن؟" — 4-card row: الكاش المسجل (big value 1,750.00 after sale, dark Warm-Ink numerals), لي عند العملاء / عليّ للموردين / مال المالك المسجل — each shows action chip "غير مسجل — سجّله" instead of a zero. Empty = action, not zero.
- Sections "مالي" (صفحة الأساس ← / افتح ←) and "منتجاتي وخدماتي" (افتح ←) as white cards with terracotta "افتح" buttons.
- "آخر ما حدث" activity row after sale: date + "بيع مباشر" + name + "نقدي داخل" + "تقييد داخل" chips + amount "250.00 د.أ" isolated LTR.
- Bottom nav: مشروعي الآن / العمل / سجّل (raised terracotta circular FAB) / مالي / أدواتي. Active tab gets a light teal tinted pill.
- BEFORE any data, Home's cash card was EMPTY (no number, no "0.00") — value only appears after a record exists.

## 3. العمل (Work) — /orders
- Subline: "الطلبات والمبيعات والمسودات والمواعيد — وكل قسم يظهر عند وجود سجل فعلي."
- Priority card pattern: "الأولوية الآن / ما نعرفه الآن: لم تحفظ طلبًا أو مسودة محلية حتى الآن. / الخطوة التالية: ابدأ بطلب واحد من عميل تعرف قصته."
- "مبيعاتي" rows appear only with data; row = name + date + "الكمية: 1" + "المحصل (د.أ): 250.00" + "الخطوة التالية: راجع أو صحح البيع عند الحاجة."
- Sections: المواعيد (افتح جدول المواعيد), quick actions تسجيل بيع مباشر / منتجاتي وخدماتي / المواد والمخزون.
- Before data: page was mostly empty headings + "يومك مفتوح — سجّل أول بيع" region.

## 4. سجّل (Record FAB)
- Dialog "ماذا تريد أن تسجّل؟" with 5 named actions + one-line explanations: تسجيل بيع / تسجيل مصروف / طلب من عميل / مسودة تصميم / عربون أو تحصيل ("ورقة تحصيل: مين عليه إلك وكم قبضت — بالوجهة التي تختارها").

## 5. Sale form ("سجّل بيعًا الآن")
- Fields: وصف اختياري; مبلغ البيع 0.00; "هل تعرف تكلفته؟" = "لا أعرف الآن — الربح «غير متاح» لا صفر" or "نعم، أعرفها"; "هل بقي شيء عليه؟" = قُبض المبلغ كاملًا / آجل — الباقي دين باسم الزبون; "وجهة القبض" = الدرج (default when exists) / غير الموزع — يبقى هنا حتى توزّعه بقرار.
- Submit → dialog "وصل التسجيل" with "افتح السجل" / "تم".

## 6. Sale detail (correction)
- Title "تصحيح بيع مباشر"; honesty limit: "حد الحقيقة — التحصيل ليس ربحًا" with "+ اقرأ حد الربح" disclosure.
- Progressive-disclosure explainers: "+ معنى الكمية", "+ معنى «لا أعرف الآن»", "+ ربط مرجع (اختياري)".
- Price/collection fields labeled "بالدينار الأردني"; "اتركه فارغًا إذا قبضت كامل السعر".
- Explicit: "لا يُحذف السجل عند إلغائه."

## 7. مالي (Finance)
- Breadcrumb "مشروعي الآن ←", context line "الصورة العامة · المبالغ (د.أ)", h1 "مالي".
- Tabs: "الوضع الآن" (selected underline) / "شو صار خلال الفترة".
- Card "قبض ودين ونتائج": 2×2 mini-grid (من العملاء لحد الآن 0.00 / خلال الفترة المختارة 0.00 / عليّ للموردين 0.00 / التزامات...) with honest empty notes; "لم تُسجّل مصاريف تشغيلية ضمن الفترة المختارة. فتح الفترة يسمح بالمقارنة."
- Period chip "الفترة المفتوحة: آخر 30 يوم" with dates + open/edit.
- Net result card on light TEAL tint with teal numerals (0.00) — live uses a green/teal secondary semantic beyond terracotta/warm-ink.
- "مال المالك" card: المسجَّل ضمن مالي 0.00 د.أ + 2 mini stats + solid terracotta "افتح مال المالك".
- Grid of value cards: الكاش المسجل 1,500.00 (subtitle "محافظ معلنة + غير موزع"), دين صافي العملاء, عليّ للموردين, رصيد الكاش لحظة العد.
- "ما نعرفه الآن" — long muted text block (known/unknown inventory) + link list: دفتر الناس، الموردون والمشتريات، عدّ الصندوق، كشف الفترة، قراءة الفترة الكاملة، فحص سلامة مالي.
- Period tab: two collapsed disclosures (قراءة الفترة… / التغطية والتعادل…) + "كشف الفترة البسيط" card ("قصة الأسبوع ببساطة") + activity reader.
- Bottom sections: الجهات / اليومية / الفترية / تسجيل مصروف أو فحص سلامة / آخر ما حدث / السجل الكامل.

## 8. فحص سلامة مالي (integrity check)
- "أداة قراءة"; promise card: "يقرأ أرقامك ولا يغيّر شيئًا. لا يصلح الفحص ولا يعدّل سجلًا تلقائيًا…".
- "ستّة عشر فحصًا تقرأ أرقامك كما هي — النتيجة والكاش والأحداث والأمانات والمخزون والأصول والقروض والعربون."
- Result: "سليم — الأرقام متسقة" + note "«لا خلل مكتشفًا» يعني أن أرقامك متسقة مع قواعدها — لا يعني أنك رابح؛ الفحص يقيس الاتساق لا الجدوى." + version line "إصدار الفحص: قواعد المخطط 35 · التصدير 27". Each check rendered as article with status word "سليم".

## 9. أدواتي (Tools)
- H1 "احسب قبل أن تلتزم"; subline "حاسبة تفكير مستقلة: تعمل بلا طلب وبلا مخزون وبلا تسجيل منتج — والنتيجة تقديرية دومًا."
- "قاعدة الأداة" card (strong empty in a11y tree), حاسبة التكلفة والسعر (افتح الحاسبة), تقديراتي المحفوظة, "حالة الوحدات" — 9 unit modules as rows with "افتح" (one disabled).

## 10. Visual language observed in live
- Warm cream canvas, white cards, soft borders, modest radius, very restrained shadows.
- Terracotta (#D97757-family) for FAB, primary "افتح" buttons, avatar, some links.
- TEAL/green secondary accent visibly used for: active nav pill tint, cash card icon, "لي عند العملاء" icon, net-result card tint+numerals, inline links (صفحة الأساس، افتح السجل الكامل). This is IN ADDITION to the documented terracotta/warm-ink roles — apparent live-only semantic (asset/positive/attention-free link color). Not found (pending verification) in the Standard docs.
- Dark mode exists and works (dark warm surfaces, terracotta persists) — diverges from Standard's light-only direction.
- Numerals: Western/English digits, LTR isolation inside RTL text, currency "د.أ", two decimals.
- Empty states are honest actions ("غير مسجل — سجّله"), never invented zeros.
- Full-page screenshots show the fixed bottom nav mid-page — capture artifact only; verified in-viewport that content is NOT occluded.

## Limitations of this session
- Only routes reachable from setup were explored: setup, foundation, home, orders (+sale detail), finance (+integrity tool), tools, record dialog. Parties/suppliers/purchases/notes/collections detail pages were NOT each opened (time-boxed) — repository analysis covers them.
- No order lifecycle was completed end-to-end (only a direct sale); lifecycle states beyond sale were read from UI copy, not exercised.
