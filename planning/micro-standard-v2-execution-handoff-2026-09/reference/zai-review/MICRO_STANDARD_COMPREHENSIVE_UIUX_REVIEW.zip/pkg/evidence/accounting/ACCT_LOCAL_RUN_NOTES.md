# Accounting — Local Run Observation Notes (Sub-agent shared evidence)

- Local run: SUCCEEDED. `npm install` + `vite build` + `vite preview` at http://localhost:4173 (React 18 + Vite + Tailwind + Dexie PWA). Title: "الحسابات - إدارة المحاسبة والطلبات". Viewport 390×844, Arabic RTL.
- Onboarding (3 quick steps): welcome + shop name ("أهلاً بك" + متجري) → activity type cards (منتجات جاهزة / منتجات أُصنِعَت، each with icon + example items) → usage mode cards (البسيط / المتوسط / المتقدم with feature lists). No credentials required.

## Visual/composition observations (actual screenshots in this folder, acct-01…12)

### Home ("أهلاً بك")
- Greeting header band (tan/beige surface) with title + date/time; date shows "13/09/2026 05:45" with the time leading in LTR — minor bidi awkwardness observed.
- OWNERSHIP SPLIT hero: two ownership values "حق المحل" (dark maroon, wallet icon) and "حق التاجر" (green, coin icon) each with 0 and a role caption ("رأس المال — للتعبئة" / "الأرباح — آمن للصرف") + guidance line "لا تسحب من «حق المحل» إلا لإعادة تعبئة البضاعة". Color+word+icon triple-encoding of a financial rule.
- Two-column quick stats: "قبض اليوم" (green down-left icon) / "صرف اليوم" (red up icon).
- "الطلبات القادمة" section with "عرض الكل" terracotta link; empty state = big icon circle + "ما في طلبات بعد، أضف أول طلب".
- "صافي هذا الشهر" card with 3-column mini stats: كسبت (green) / خسرت (red) / صافيت (dark).
- Dismissible tinted action cards: red-tinted "حماية بياناتك" (backup via WhatsApp, terracotta button) and green-tinted "أدخل رصيدك الحالي" (solid dark-green primary + light "لاحقاً"). Onboarding nudges persist with × dismiss.
- Bottom nav 5 items: الرئيسية / المالية / الطلبات / بيع سريع / الإعدادات; active item = terracotta tinted pill + terracotta icon/text.

### المالية (Finance)
- White summary card: "صافي هذا الشهر 0+" (green) with كم قبضت (green) / كم صرفت (red).
- Filter pills: الكل (active terracotta solid) / قبض / صرف / سحب.
- Two doorway cards with tinted icon chips: الديون (blue icon) "لهم عندي / عندي لهم", التقارير (terracotta) "ربح صافي".
- Transaction list empty state with icon + title + subline.

### الطلبات (Orders)
- View toggle قائمة/تقويم; status chips WITH counts: الكل 1 / قيد التنفيذ 1 / جاهز 0 / مغلق 0 (active chip solid terracotta with white text).
- ORDER ROW (rich): right avatar circle (tinted, person icon) + bold customer name "أبو أحمد" + type caption "تركيب ستارة"; status badge "قيد التنفيذ" in amber/gold tint; LEFT zone amount "150" bold + clock icon + "الآن"; AMBER/GOLD vertical edge stripe on the row's side marking in-progress state; internal divider separating identity zone from amount zone; summary line "إجمالي الطلبات: 1" below list.

### Order detail (bottom sheet)
- Sheet with drag handle + hint "↑ اسحب للأعلى للتوسّع", dimmed backdrop, page visible behind.
- Identity row (avatar+name+type+amber badge), amount card "المبلغ 150" + payment state "غير مكتمل" with clock icon, execution datetime row.
- COMMITMENT ACTION = SOLID DARK GREEN "إتمام الطلب والبيع" with check icon (commit/completion is green, not terracotta).
- Status switcher "تغيير الحالة": segmented قيد التنفيذ (active) / جاهز.
- Secondary actions: مشاركة (solid green) / تعديل (solid terracotta). Danger: "حذف الطلب" as light-red tinted card with dark-red text.

### الديون (Debts)
- TWO SOLID HERO CARDS: "إجمالي عندي لهم 0" (dark red solid, white text) and "إجمالي لهم عندي 0" (terracotta solid). Direction of money encoded by solid surface color.
- Segmented: عندي لهم (solid green active with ↓) / لهم عندي (white).
- Green-tinted quick-add card: "إضافة دين لهم عندي — زبون يشتري الآن ويدفع لاحقاً" with + chip.
- Clean empty state: check icon + "ما عندك ديون، كلكا مخلصة" + subline.

### التقارير (Reports)
- Period segmented control (اليوم/الأسبوع/الشهر/الماضي/السنة/السنة المالية) + two date inputs.
- BIG SOLID TERRACOTTA HERO: "في هالأيرة كسبت 0 ربح صافي" — the period's net result as the page's visual anchor.
- Stat cards: قبضت (green) / صرفت (red).
- "مبيعات يومية" white card containing a CHART (daily sales, faint red axis/grid with tick labels 5, 10) — real data visualization with axis ticks.
- Counts: إجمالي الطلبات 1 / طلبات مكتملة 0. Link "تغيير إلى عرض احترافي من الإعدادات".

### البيع السريع (Quick sale)
- Empty state: "ما في منتجات سريعة، أضف منتجاتك الأكثر مبيعاً" + منتج جديد button.

### الإعدادات (Settings)
- LONG grouped page: sections المزامنة السحابية / بيانات النشاط / إدارة البيانات / واتساب / التقارير / المخزون / المظهر / التنبيهات والمساعد / مساعدة.
- Rows = icon chip + bold title + muted subtitle + chevron or value; segmented controls (مفعل/غير مفعل; عربي/كنتر; مزرقة/مضيوطة; مفعل/خفيف); terracotta toggle switches; helper paragraphs; version footer "حول التطبيق — الحسابات v1.0.0". Dense but scannable through group headers and row rhythm.

## Transferable benchmark principles observed (not to copy)
1. Money direction always triple-encoded: color + word + icon (green/red/maroon vs neutral).
2. Solid-color hero cards anchor each page's ONE primary reading (net result, total debts) — one per page, rest stays white.
3. Rows carry 5–6 channels: avatar/icon, name, type caption, status badge, time/context, amount zone — with an internal divider separating identity from value.
4. Status has BOTH a badge (word) and an edge stripe (color) — readable without color.
5. Commitment/completion actions are a distinct hue (dark green) from brand actions (terracotta) — user learns "green = closes/commits money".
6. Empty states are instructive ("أضف أول طلب") with a direct action button, plus illustration icon.
7. Sheets layer over dimmed pages with drag affordance; primary action inside the sheet.
8. Charts appear in Reports with axes/ticks; numbers stay big and isolated.
9. Settings/long pages stay scannable via group headers + consistent row anatomy.
10. Onboarding nudges persist as dismissible tinted cards (backup, opening balance) — honest, actionable.

## Limitations
- Inspected in advanced mode with one test order; deep flows (BOM inventory, PDF export, calendar view, WhatsApp share) were not exercised.
- The repo also ships static design-identity HTML files (هوية بصرية - نظام الألوان.dc.html, هوية بصرية - نظام المكوّنات (موبايل).dc.html) and نظام-التصميم-SOP.md — available for the benchmark reviewer as design-source material.
