# Micro — logo package

The master source for every future use is **SVG**. Plain vector paths, no filters,
no raster, no embedded fonts, no external references. Opens and edits cleanly in
Figma, Illustrator, Inkscape, Sketch and any browser.

PDF is for print shops. PNG is for places that will not accept a vector.
Never scale a PNG up — go back to the SVG.

---

## Construction

- Artboard: 192 × 192 units, 24-unit modules.
- The DRAWN INK occupies the inner 168 units (87.5%) — 12 units of margin per side.
  A 36px frame therefore renders the mark at ~31.5px, below the 32px minimum.
  Size frames from the ink, or use the compact variant.
- One six-point keystone form, rotated 90° / 180° / 270° about 96,96.
- POLYGON CORNERS (construction input, NOT points on the finished curve),
  clockwise from top-left: 50,12 · 142,12 · 133,60 · 108,74 · 84,74 · 59,60
- Corner radii, same order: 30 · 30 · 15 · 9 · 9 · 15
- Rounding pulls each corner inward, so the curve's anchors land elsewhere (the top
  edge runs from about 54.7 to 137.3). To reproduce the shape EXACTLY, use the path
  below — do not re-derive it from the corner list.
- Open centre: 44 × 44 units (~23% of width). Never fill it.
- Clear space: X = 16 units minimum, 2X preferred, measured from the 192-unit
  artboard edge. Since the ink is already inset 12 units, true clearance is X + 12.

Unit path:

    M80 12L112 12Q142 12 136.47 41.49L135.76 45.26Q133 60 119.91 67.33L115.85 69.6
    Q108 74 99 74L93 74Q84 74 76.15 69.6L72.09 67.33Q59 60 56.24 45.26L55.53 41.49
    Q50 12 80 12Z

### Optical weight correction (deliberate — do not normalise)

Applied about 96,96 after rotation.

| Form | Light backgrounds | Dark backgrounds |
|---|---|---|
| Ink / ivory | ×1.025 | ×0.975 |
| Turquoise | ×1.0 | ×1.0 |
| Taupe / warm brown | ×0.975 | ×1.02 |
| Terracotta | ×1.0 | ×1.0 |

### Minimum sizes

- Primary mark: 32px
- Compact variant: 16–32px
- App icon: 40px rendered
- Below 16px: single-colour terracotta silhouette of the compact variant

---

## Colour

| Name | HEX | RGB | CMYK | Contrast on ivory |
|---|---|---|---|---|
| Warm Terracotta | #CC785C | 204 120 92 | 0 · 48 · 55 · 13 | 3.1:1 |
| Turquoise | #079FA0 | 7 159 160 | 85 · 12 · 38 · 2 | 3.1:1 |
| Near-Black Ink | #1F1E1D | 31 30 29 | 65 · 60 · 60 · 70 | 16.1:1 |
| Warm Taupe (brand-neutral, LOGO ONLY) | #B79C86 | 183 156 134 | 8 · 25 · 38 · 16 | 2.4:1 |
| Warm Brown (brand-neutral-dark, LOGO ONLY) | #8C7A66 | 140 122 102 | 12 · 26 · 40 · 30 | 4.3:1 on #1C1917 |
| Warm Ivory | #FAF9F5 | 250 249 245 | 1 · 1 · 3 · 0 | logo field |
| Dark Background | #1C1917 | 28 25 23 | 66 · 62 · 62 · 72 | logo field |

Dark set on #1C1917 — measured: #D59172 (6.8:1) · #5EC0C1 (8.2:1) · #8C7A66 (4.3:1) · #FFF7ED (16.6:1)

CMYK values are press targets — proof before any run.

Rules: brand colour never encodes financial meaning; no colour represents a product
area, account or number; the four colours are never recoloured for a campaign;
terracotta and turquoise are never a good/bad pair.

### Alignment with the Micro repository

Three of the four logo colours ARE the product's existing tokens — read them from
the tokens, never re-type the hex:

    brand-primary   #CC785C
    accent-primary  #079FA0
    text-primary    #1F1E1D
    canvas          #FAF9F5

TWO new values, both LOGO-ONLY — register both:
    brand-neutral       #B79C86   light backgrounds
    brand-neutral-dark  #8C7A66   dark backgrounds
Neither may be used for interface surfaces, borders or text. The existing interface
neutrals were tested and rejected for the mark — `divider` #DAD5C8 measures about
1.2:1 on canvas and `border` #EAE6DC even less, so the fourth form would vanish at
icon sizes. #B79C86 is the nearest value in the same warm family that survives 40px.

The repository's rule that brand colour is not status colour holds without
exception: income, expense, withdrawal and return colours are never logo colours.

### Transparent vs opaque — two surfaces, two rules

INSIDE THE PRODUCT: the mark sits on a TRANSPARENT background and inherits the
surface beneath it (micro-quad.svg on light, micro-quad-dark.svg on dark).

AS AN APP ICON: the field is always OPAQUE. iOS rejects transparency outright and
Android composites it onto an unpredictable colour. The icon files are opaque by
design. This is not a contradiction — it is a different surface with a different
requirement.

---

## Motion

**Allowed** — motion that resolves. Forms may fly in, rotate into place or settle
inward, as long as the animation ends, decelerates, and stops on the locked mark.
Suggested: 600–900ms total, 60–80ms stagger per form, ease-out, no bounce,
no overshoot beyond 2%.

**Forbidden** — motion that never ends. Never a continuous rotation, never a
loading spinner, never a looping pulse. Build a separate loading indicator from a
single form if one is needed.

`assets/motion/` holds each form as its own file, already rotated into final
position on the shared 192-unit artboard, so easing every layer back to identity
reassembles the mark pixel-exactly. `micro-mark-layered.svg` is one file with four
named groups for After Effects, Rive, Lottie or Figma import.

---

## Files

### Vector masters — assets/
    micro-quad.svg                    primary, light backgrounds
    micro-quad-dark.svg               dark backgrounds
    micro-quad-ink.svg                one colour, ink
    micro-quad-ivory.svg              one colour, ivory
    micro-quad-compact.svg            below 32px

### Icon masters — assets/
    micro-appicon-quad.svg            ivory field (default)
    micro-appicon-quad-dark.svg       dark field
    micro-appicon-quad-terracotta.svg terracotta field (alternate)
    micro-adaptive-foreground.svg     Android adaptive, 432, mark at 60%
    micro-adaptive-background.svg     Android adaptive background layer
    micro-maskable.svg                PWA maskable, 512, mark at 58%
    micro-favicon-field.svg           browser tab, ivory field
    micro-favicon-field-dark.svg      browser tab, dark field

### Motion — assets/motion/
    light/1-top-ink.svg  …  light/4-left-terracotta.svg
    dark/…                            same four, dark set
    mono/…                            same four, one colour (masks/mattes)
    micro-mark-layered.svg            four named layers, light
    micro-mark-layered-dark.svg       four named layers, dark
    micro-assembly.json               Lottie, 60fps, 55 frames

Lottie: play ONCE, never loop. Works with lottie-web, lottie-react-native and
Flutter's Lottie package. Stagger 4 frames (67ms), resolves and locks at frame 54
(900ms) where a "locked" marker sits — both inside the documented ranges below.

### Splash screens — assets/splash/
    ios-1290x2796.svg                 iPhone master, light (+ -dark)
    ios-1179x2556.svg                 iPhone 15/16 standard
    ipad-2048x2732.svg                iPad
    android-960x960-icon.svg          Android 12+ splash icon (+ -dark)

Mark size on splash: ~25% of screen width. Android 12+ crops to a 240dp circle,
so the mark sits at 40% of the 960 square.

### Browser
    favicon.ico                       48 + 32 + 16 in one file

### Lockups — assets/lockup/
    micro-latin-light.svg  · -dark · -ink       Mark + "Micro", LTR
    micro-arabic-light.svg · -dark · -ink       Mark + "مايكرو", RTL

These carry LIVE text, so the fonts must be installed to render correctly.
Outline the text for any file leaving your control (printer, partner, agency).

TYPEFACES — SETTLED, not pending:
  Arabic  IBM Plex Sans Arabic Medium   SIL OFL, free for commercial use
  Latin   Instrument Sans Medium        tracking -3%
The Arabic face is the same one the Micro product already uses. Never apply
negative letter-spacing to Arabic.

INSTRUMENT SANS IS LOGO-ONLY. It must never enter the product interface, which is
typeset in IBM Plex Sans Arabic and IBM Plex Mono. This keeps a third typeface out
of the codebase.

The Arabic lockups pin the word's RIGHT edge with x="438" + text-anchor="end" and
carry NO direction attribute — Unicode bidi shapes Arabic correctly on its own.
Do not add direction="rtl" with x="0": that pushes the word off the canvas.

NAME — SETTLED: مايكرو (matches the product's AppHeader). Not ميكرو.

Gap between mark and word = 2X. Never mix Arabic and Latin in one lockup.
Never use a lockup as an app icon — the icon is the mark alone.

Lockup motion: the mark resolves FIRST, then the word arrives — word delay 820ms
after the mark starts. The word never animates before the mark, never moves after
the mark has settled, and never animates letter by letter.

### Print — assets/print/
    micro-mark-colour.pdf             true vector, curves only
    micro-mark-mono-ink.pdf           one colour

### Raster — assets/png/
    mark/light-{1024,512,256,128,64,32}.png
    mark/dark-{1024,512,256}.png
    mark/mono-ink-{1024,512}.png · mono-ivory-{1024,512}.png
    mark/compact-{32,24,16}.png
    icon/ios-android-{1024,512,192,180,152,120,76,60,40}.png
    icon/appicon-dark-512.png · appicon-terracotta-512.png
    icon/android-adaptive-foreground-{432,216,108}.png
    icon/web-maskable-512.png
    icon/favicon-{48,32,16}.png

---

## Never

Rotate or tilt the static mark · loop it as a spinner · stretch or squash it ·
rebuild the proportions · fill the open centre or place a glyph in it · add
gradients, shadows or glows · place it on a busy photo · use it to label a product
area (Manage, Services, Market, Delivery) · extract a single form as a sub-brand ·
use it as a status indicator.

---

## Settled

- Name: مايكرو (Arabic) / Micro (Latin)
- Typefaces: IBM Plex Sans Arabic Medium · Instrument Sans Medium
- Fourth colour: #B79C86, registered as brand-neutral, logo only
- Default app-icon field: ivory. Terracotta is the launch-campaign alternate;
  never ship both to the same user.
- Drawn Arabic lettering: not pursued. The product's own typeface keeps the logo
  and the interface in one voice.

## Open decisions — three, none answerable from this document

1. Pantone equivalents — only if you print with spot colours, and only chosen
   against a physical swatch book at your printer. Never from a screen.
2. A trademark similarity search, by an attorney, before any registration.
   Four-part radial marks are common enough that this matters.
3. Whether print, packaging or signage is in scope this year. The vector and PDF
   masters are ready either way.
